import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable

//logowanie
WebUI.openBrowser(rawUrl=GlobalVariable.url)

WebUI.maximizeWindow()

WebUI.setText(findTestObject('Object Repository/PageLogin/input_username'),username )

WebUI.setEncryptedText(findTestObject('Object Repository/PageLogin/input_password'),password)

WebUI.click(findTestObject('Object Repository/PageLogin/button_login'))

//assert napisu product
str_list_name= WebUI.getText(findTestObject('Object Repository/ProductList/str_products'))
assert list_name == str_list_name

//klikniecie w produkt
WebUI.click(findTestObject('Object Repository/ProductList/a_item_view'))

//dodanie do koszyka
WebUI.click(findTestObject('Object Repository/PageItem/btn_add_to_cart'))

//assert liczby towaru w koszyku
count_cart= WebUI.verifyElementVisible(findTestObject('Object Repository/ProductList/a_shoping_cart'))
assert count_cart == true

//przejscie do koszyka
WebUI.click(findTestObject('Object Repository/ProductList/a_shoping_cart'))

//przejscie do checkoutu
WebUI.click(findTestObject('Object Repository/PageCart/a_checkout'))

//wpisanie name/lastname/zip

WebUI.setText(findTestObject('Object Repository/PageYourInfo/input_first_name'), first_name)
WebUI.setText(findTestObject('Object Repository/PageYourInfo/input_last_name'), last_name)
WebUI.setText(findTestObject('Object Repository/PageYourInfo/input_zip'), zip_code)

WebUI.click(findTestObject('Object Repository/PageYourInfo/btn_continue'))

WebUI.click(findTestObject('Object Repository/PageOverview/a_finish'))


//assert count_cart == false

WebUI.click(findTestObject('Object Repository/PageOverview/btn_sidebar'))

WebUI.click(findTestObject('Object Repository/PageOverview/a_logout'))

WebUI.closeBrowser()











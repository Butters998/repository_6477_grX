<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>Test wiadomości w przypadku próby logowania zablokowanego użytkownika</description>
   <name>TS02-Logowanie zablokowany uzytkownik</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>4b8c1ee1-6348-43a5-a917-f8197f313941</testSuiteGuid>
   <testCaseLink>
      <guid>e2253215-4a97-4d4e-8fd5-6bdeb52ed4b7</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Zakup produktu/Logowanie do aplikacji/Logowanie do aplikacji- zablokowane konto</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>9f2b69e6-3997-4f8f-8e2b-40df161cd04e</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Dane saucedemo/Data1</testDataId>
      </testDataLink>
      <variableLink>
         <testDataLinkId>9f2b69e6-3997-4f8f-8e2b-40df161cd04e</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>err_username</value>
         <variableId>d67c39e1-e8a6-4e6f-8997-3bb89ab9f4e7</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>b8942e60-665a-45f4-b955-b8dbb8b3107d</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>9f2b69e6-3997-4f8f-8e2b-40df161cd04e</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>password2</value>
         <variableId>5091a758-97dd-42f9-a93a-8b577aabd879</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>

<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Zatwierdzenie kupna towaru- checkout</description>
   <name>a_checkout</name>
   <tag></tag>
   <elementGuidId>b5eee1bf-03f6-4731-9f40-d379f5309aca</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a[class=&quot;btn_action checkout_button&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

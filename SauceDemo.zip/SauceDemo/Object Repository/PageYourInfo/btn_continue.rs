<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>zatwierdzenie wpisanych danych</description>
   <name>btn_continue</name>
   <tag></tag>
   <elementGuidId>91594513-d7cb-49cf-bfcb-99a6ce5b23d3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[class=&quot;btn_primary cart_button&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

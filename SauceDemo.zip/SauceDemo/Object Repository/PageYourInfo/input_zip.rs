<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>kod pocztowy</description>
   <name>input_zip</name>
   <tag></tag>
   <elementGuidId>ff1c21d3-721b-4adb-b58f-642e06a322d2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;postal-code&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Identyfikator użytkownika</description>
   <name>input_username</name>
   <tag></tag>
   <elementGuidId>79bb262c-8e6e-477b-b40e-e9f1c447a7d0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;user-name&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

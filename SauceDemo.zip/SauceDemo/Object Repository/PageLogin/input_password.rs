<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Hasło użytkownika</description>
   <name>input_password</name>
   <tag></tag>
   <elementGuidId>331bbcf1-d091-4d10-bf9c-8fbb723696b7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;password&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Opcja zaloguj</description>
   <name>button_login</name>
   <tag></tag>
   <elementGuidId>deb69c64-0630-4439-a2c7-cd47fe4363f9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;login-button&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

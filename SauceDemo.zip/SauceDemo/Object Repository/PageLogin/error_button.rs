<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>błąd podczas logowania</description>
   <name>error_button</name>
   <tag></tag>
   <elementGuidId>d5fb5b90-8208-4767-8576-60bc52bfbf4b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h3[data-test=&quot;error&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

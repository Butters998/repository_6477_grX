<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>cena towaru</description>
   <name>txt_item_price</name>
   <tag></tag>
   <elementGuidId>78d96f05-45c3-4c32-9ecb-f423f889f7e7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div[class=&quot;inventory_item_price&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>dodanie towaru do koszyka</description>
   <name>btn_add_to_cart</name>
   <tag></tag>
   <elementGuidId>9627720c-0f51-4a35-a59b-e68199db3b58</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button[class=&quot;btn_primary btn_inventory&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

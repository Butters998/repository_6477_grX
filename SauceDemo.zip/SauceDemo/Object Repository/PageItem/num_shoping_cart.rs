<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>liczba wyświetlająca ilość przedmiotów w koszyku</description>
   <name>num_shoping_cart</name>
   <tag></tag>
   <elementGuidId>32fa96d0-846b-4247-a6ce-0647090882b7</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

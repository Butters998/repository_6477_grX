<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>zakończenie transakcji</description>
   <name>a_finish</name>
   <tag></tag>
   <elementGuidId>073fd7e3-9b8f-4a6f-a35d-dc7f46c3166a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a[class=&quot;btn_action cart_button&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

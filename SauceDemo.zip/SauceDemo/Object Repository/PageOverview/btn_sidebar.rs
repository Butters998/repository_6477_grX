<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>otwarcie panelu nawigacyjnego</description>
   <name>btn_sidebar</name>
   <tag></tag>
   <elementGuidId>1fd2f484-d2ad-42df-9251-a6a1c2ad1a5d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div[class=&quot;bm-burger-button&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

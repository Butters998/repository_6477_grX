<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Wylogowanie użytkownika</description>
   <name>a_logout</name>
   <tag></tag>
   <elementGuidId>f91346cd-fef3-4510-8765-912a7cdc9c26</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a[id=&quot;logout_sidebar_link&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

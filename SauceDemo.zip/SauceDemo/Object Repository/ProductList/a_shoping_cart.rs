<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Otwarcie koszyka sprzedażowego</description>
   <name>a_shoping_cart</name>
   <tag></tag>
   <elementGuidId>971ec926-f743-4e8c-bbc4-be68a3d04fda</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span[class=&quot;fa-layers-counter shopping_cart_badge&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

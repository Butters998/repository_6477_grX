<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>lista produktów</description>
   <name>str_products</name>
   <tag></tag>
   <elementGuidId>24d56ddd-dae1-425c-b2e5-97b3570963aa</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div[class=&quot;product_label&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

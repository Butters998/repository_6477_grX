<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Podgląd towaru</description>
   <name>a_item_view</name>
   <tag></tag>
   <elementGuidId>daef84c4-547a-48a4-b256-b35d855c994e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a[id=&quot;item_4_title_link&quot;]>div[class=&quot;inventory_item_name&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
